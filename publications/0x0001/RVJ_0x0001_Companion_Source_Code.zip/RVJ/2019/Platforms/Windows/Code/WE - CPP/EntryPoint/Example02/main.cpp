/*

AUTHOR: Roger Villela
E-MAIL: RVJ.Education@OpenMind.OnMicrosoft.com
CONTACT: RogerVillelaJournal@OpenMind.OnMicrosoft.com
LINKEDIN: https://www.linkedin.com/in/rogervillela

(EN-US) MATERIAL FOR EXCLUSIVE EDUCATIONAL AND INFORMATIVE USE

The use of this example project and other materials created, provided and presented directly by ROGER VILLELA, hereinafter referred to as the SOLE AUTHOR and SOLE HOLDER of the rights in any present or future context, are dedicated solely to Educational use through courses and other commercial or free products of authorship of the exclusive authors, which the EXCLUSIVE AUTHOR presents and can present throughout the national and international territory through various means of communication and distribution, such as electronic documents, print-outs, social networks and purpose-compatible groups such as blogs and other types of sites for presentation of educational technical content, conferences through products such as Microsoft Skype (Copyright- All rights reserved), Microsoft Teams (copyright-All rights Reserved), Microsoft Skype for Business (copyright-All rights Reserved), and others that are relevant to the educational technical purpose. The EXCLUSIVE AUTHOR is not liable, directly or indirectly, for the use made by third parties of this or other products. The EXCLUSIVE AUTHOR does not implicitly authorize any physical person and person legal, to use their products or their name without the proper commercial and legal contracting. The commercial and legal contracting must follow according to the rules determined in each district, province, principality, kingdom, city, state and country that demonstrate interest. Prior to the commercial and legal rules determined in each geographical context, the terms first formalised by the EXCLUSIVE AUTHOR and which need to be accepted and fulfilled in their entirety for such hiring to be officially recognized by the EXCLUSIVE AUTHOR.

MICROSOFT VISUAL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

		-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
		-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
		-> Use Microsoft Visual Studio 2017 (RTM) as minimum platform.
		-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
		-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
		-> Use the .NET Framework version 4.0 (RTM) as minimum version.
		-> They use the latest version of the .NET Framework (RTM) from the minimum version criterion and as provided.

INTEL PARALLEL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

	-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
	-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
	->  Use Microsoft Visual Studio 2017 (RTM) as minimum platform for the integration environment.
	-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
	-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
	-> Use Intel Parallel Studio 2018 as a minimum platform.
	-> They use the latest version of Intel Parallel Studio from the minimum version criterion and as provided.


INTEL C++ / MICROSOFT VISUAL C++

-> The key code compiles with other versions of Intel C++ / Microsoft Visual C++, provided that there are support for the resources used in the directly related codes and files. But the project file (vcxproj) may be incompatible as a function of changes made through the versions/updates.
-> Compilation options can also vary between versions/updates. If you use another Intel C++ / Microsoft Visual C++ version/update, adjustments may be required.

MICROSOFT WINDOWS SDK

-> The sample projects are always distributed and configured to use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM). However, they are compatible with the Microsoft Windows SDK 10.0.10240.0 onwards.
-> The key code also compiles with other versions of the Windows SDK. However, adaptations may be required as a function of build options and support for features in libraries and header files.

SOFTWARES && TECHNOLOGIES

==> Operating Systems

-> Microsoft Windows 10 (October 2018 Update / a.k.a. 1809)
-> Microsoft Windows 10 (April 2018 Update / a.k.a. 1803)
-> Microsoft Windows 10 (Fall Creators Update)
-> Microsoft Windows 10 (Creators Update)

==> Compilers

-> Microsoft C++
-> Intel C++

==> Platform: Windows OS

-> C++ programming language.
-> Assembly (Intel x86, Intel x64, Intel 64).


==> Platform: CLR (Common Language Runtime)

-> C++/CLI (Common Language Infrastructure) projection.
-> CIL - Common Intermediate Language.
-> C# Programming Language.


==> Platform: WinRT (Windows Runtime)

-> C++/CX (Component Extensions) projection.
-> C++ programming language.


==> Libraries

-> Microsoft UCRT - Universal C Runtime.
-> Microsoft CRT - C Runtime.
-> WinRT Libraries.
-> Windows API's (Application Programming Interfaces).
-> C++ Standard Library.
-> C++ STL - Standard Template Library.
-> STL/CLR Library.
-> BCL - Base Class Library (core set).
-> FCL - Framework Class Library (complete set).

==> Intel Parallel Studio (Intel  C++)

->	2019 (RTM, Update 1).
->	2018 (RTM, Update 3).

==> Microsoft Visual Studio 2019 (Microsoft Visual C++)

-> 16.n.n

==> Microsoft Visual Studio 2017 (Microsoft Visual C++)

-> 15.9.n
-> 15.8.n
-> 15.7.n
-> 15.6.n
-> 15.5.n
-> 15.4.n
-> 15.3.n
-> 15.2.n
-> 15.0.n


==> Microsoft Windows SDK(s) (including updates)

-> 10.0.17763.n (Microsoft Windows 10 version 1809 / a.k.a. October 2018 Update)
-> 10.0.17134.n (Microsoft Windows 10 version 1803 / a.k.a. April 2018 Update)
-> 10.0.16299.n (Microsoft Windows 10  version 1709 / a.k.a. Fall Creators Update)
-> 10.0.15063.n (Microsoft Windows 10 version 1703 / a.k.a. Creators Update)
-> 10.0.15052.n
-> 10.0.14965.n
-> 10.0.14393.n (Microsoft Windows 10 version 1607 / a.k.a. Anniversary Edition)
-> 10.0.10586.n (Microsoft Windows 10)
-> 10.0.10240.n (Microsoft Windows 10)


INTRODUCTION

	int main( int argc, char *argv[], char *envp[] );

DETAILS

	This main function signature and implementation are specific of Microsoft C/C++ compilers and it is compatible with UNIX-based environments.

	This is a description of parameters:

	=> envp - provide access to the environment variables of the current process and is common in UNIX-based system. The envp parameter is Microsoft specific and is ANSI compatible in C programming language, but it is not ANSI C++. The envp (environment of process) is a specific parameter of Microsoft C/C++ implementation, and despite been non-ANSI C++ it is compatible with Microsoft C++ programming language implementation.  The envp (environment of process) is an array of strings	 which is a copy of the set of environment variables of the process, and should be treated as a read-only copy, this means that should not be changed directly, but only via specific functions. The array envp (environment of process) is null terminated, like the argv parameter.

	These environment variables is an information block passed to main or wmain functions and is a copy of the values at the specific moment of copy. If some value is updated in the original information block on the process, the copy of information block is not automatically updated. To obtain the most up-to-date content of the environment block of information of the process, we should obtain a new copy.


	MINIMAL FUNDAMENTAL RULES

	When working with environment variables and envp pointer, we have some fundamental rules that must be observed.

	- We should not try to directly alter the original environment block. We should use the indicated functions to this task.
	- We should not change the original envp pointer. That is, we should not alter the memory address stored in the envp pointer variable.
	- We should declare a local pointer and use this local pointer to navigate through the environment block addresses.
	- If we want to update the value of some environment variable, we must use specific Microsoft CRT / Microsoft UCRT API's presented in	this example, or apropriated Windows API's cited here but showed in another sample projects.
	- We should create a copy of the environment variables values and does not directly manipulate the original environment block.

	PROCESS AND ENVIRONMENT CONTROL

	Microsoft UCRT / Microsoft CRT have functions and data structures organized in named sets.
	One of these sets is the "Process and Environment Control". The functions and data structures in this set are specialized in manipulatio	of environment variables. We should use them to create, to modify and to remove environment variables and their respective values.

	When the Microsoft Windows operating system creates a process, a set of data structrures are instantiated too. These instances of data structures are used to store required information about the process environment and other operating system objects that are used by a Microsoft Windows process object, like a thread. One of these elements is the ENVIRONMENT BLOCK. Every Microsoft Windows process have an ENVIRONMENT BLOCK. The environment block is a memory block automatically allocated and managed by Microsoft Windows operating system and it is used to store envrionment variables and their respective values. Currently the environment block is not a specialized data structure, like stack, linked list, binary tree, for example, the enviroment block is a memory block that is allocated on process heap. The environment variables are stored as a simple sequence of strings of characters, one after another and each one separated from the other only by ONE null terminator character \0 and the first TWO null-terminator characters in sequence means that there are no more environment variables:

	Var0=Value\0Var2=Value\0Var3=Value\0VarN-1=Value\0\0

	WHICH IS THE MAXIMUM NUMBER OF CHARACTERS TO THE VALUE ASSIGNED TO AN ENVIRONMENT VARIABLE?

	Currently is 32KB (32,767) characters.

	WHICH IS THE MAXIMUM SIZE TO A MEMORY BLOCK ALLOCATED TO THE ENVIRONMENT BLOCK?

	Starting with Microsoft Windows Vista and Microsoft Windows Server 2008 there is no technical limit to the total size of the environment block of the process. With Microsoft Windows XP and Microsoft Windows Server 2003 the maximum size to the allocated memory block is 32KB.

	Now we will learn about the functions used in this example to manipulation of the environment block and environment variables.
	It is IMPORTANT to remember that some of these specific functions that are used in this sample project should no be used, because they are not supported by applications that targeting Windows Runtime, for example. Despite of this, these functions that are not supported in the Universal Windows Platform (UWP), can be used normally in Microsoft Windows Desktop applications (Win32 or Windows API). We can read more about Microsoft UCRT / Microsoft CRT functions not supported in UWP - Universal Windows Platform in this page of Microsoft official documentation:

	https://docs.microsoft.com/en-us/cpp/cppcx/crt-functions-not-supported-in-universal-windows-platform-apps?view=vs-2017

	Here is the description of the Microsoft UCRT functions used in this example.


	-> _putenv function: ADDS new environment variables or modifies the VALUES of existing environment variables. The function, it IS NOT CASE-SENSITIVE about the environment variable name or assigned value.

	When using to create an environment variable or to modify the value of an existing environment variable, we should inform the string value of environment variable using the form: varname=string value, as showed in this example:

	_putenv( "CPP=Very Cool" );


	To remove an environment variable, we should inform an empty string value, as showed in this example, but we should be aware that the function it IS NOT CASE-SENSITIVE about the environment variable name.

	_putenv( "CPP=" );


	-> _wputenv function: does the same as _putenv function but using wide-characters. The function it IS NOT CASE-SENSITIVE about the environment variable name or assigned value.
	-> _putenv_s function: does the same as _putenv function but using enhanced security. The function it IS NOT CASE-SENSITIVE about the environment variable name or assigned value.
	-> _wputenv_s function: does the same as _putenv_s but using wide-characters. The function it IS NOT CASE-SENSITIVE about the environment variable name or assigned value.

	-> getenv function: gets the value of a environment variable name. The function it IS NOT CASE-SENSITIVE about the environment variable name or assigned value.

	The function returns a pointer to the environment memory block of the currently process.
	If we informs the nullptr value, the function set errno with EINVAL value and returns the nullptr value.
	If the environment variable does not exists, the function return the nullptr value.

	-> getenv_s function: does the same as _getenv function but using enhanced security. The function it IS NOT CASE-SENSITIVE about the environment variable name or assigned value.
	-> _wgetenv function: does the same as _getenv function but using wide-characters. The function it IS NOT CASE-SENSITIVE about the environment variable name or assigned value.
	-> _wgetenv_s function: does the same as _wgetenv function but using enhanced security. The function it IS NOT CASE-SENSITIVE about the environment variable name or assigned value.

	As cited before, currently these functions are CASE-INSENSITIVE in regards of the environment variable name and  the informed value.
	Another IMPORTANT aspect of the environment variables is that we should not change the environment variables and their values
	directly, nor trying to assign a value using statements like *envp = "New value", or trying to freeing the memory block using the global array _environ[] for example, because this can lead to invalid memory address error. When we try to access memory addresses that are invalid, the access violation error occurs, and it is a common source for buffer overrun and other potential vulnerabilities that could be exploited by attackers.

*/

#ifdef __INTEL_COMPILER
#pragma warning( disable: 1079; )
#endif

#pragma region Header files
#include <RVJ.Desktop.h>
#include "Example02.h"
#pragma endregion

#ifdef __cplusplus

#pragma region Namespaces
using namespace std;
using namespace RVJ::Desktop;
#pragma endregion

#endif



int main( int argc, char* argv [], char* envp [] ) {
/*

	An example of a compatible signature but using Microsoft-specific sized integer

	__int32 main( unsigned __int32 argc, unsigned __int8* argv [], unsigned __int8* envp [] )

	The recommendation of Microsoft for sized integer is on the creation of portable code.
	
	When used, sized integer requires changes in various parts of the code for compatibility, and we must be aware of this. In a near future this source code module will be updated specifically to show how to work with Microsoft specific sized integer and why is recommended the uses of the C++ Standard Library types instead.

	Example of a compatible signature but using C++ Standard Library types available in <cstdint> header file or in the C Standard Library <stdint.h> header file.


	int32_t main( uint32_t argc, uint8_t* argv [], uint8_t* envp [] )

*/

	uint32_t bufferSize {};



#pragma region A tutorial explaining how to use the envp parameter of the main entry-point functions.

	/*

	INTRODUCTION

	SUGGESTION: You can put this block of code within the #pragma region/#pragma endregion into a function.

	How to navigate through the environment block variables and shows both, the environment variable and the associated value. The original value in the environment block on MIcrosoft Windows is stored in that way:

		ENV_VAR_NAME=Value\0ENV_VAR_NAME=Value\0ENV_VAR_NAME=Value\0ENV_VAR_NAME=Value\0LAST_ENV_VAR_NAME=Value\0\0

	After the LAST environment variable value we have TWO null terminator char in sequence, and this indicates the end of the environment block.

	As we known, we can use the syntax of pointers with an array, but we must be aware that EVERY time that we use an array with a syntax of pointer or vice-versa, the C++ programming language compiler does a data type conversion, and this is a standard ISO/ANSI implementation rule for the C++ programming language , and it is not some specific rule of a compiler tool vendor.

	*/


	/* Access to the environment block using localEnvp. */
	char** localEnvp { envp };

	/*

	SHOWS THE ENVIRONMENT VARIABLES AND VALUES.

	To show the environment variables and their values, we can do the following:

	while ( *localEnvp ) wprintf_s( L"%S\n", ( *( localEnvp++) ) );

	// OR

	while ( *localEnvp ) Console::WriteLine( u"%S\n", ( *( localEnvp++) ) );

	Very easy and simple loop with an instruction to show the values on the console.

	*/

	/* Count the number of items. */
	uint32_t count {};

	/* Iterates through all the elements in the array. */
	while ( *localEnvp ) {

		/*

		IMPORTANT: This implementation logic is just one example of a basic algorithm for this scenario, and you should explore other possible algorithms for production if you want. This basic algorithm does not have the purpose of cover every kind of possible scenarios.

		*/

		//wprintf_s( L"[%u]: Environment variable name and the value: %S\n", count++, *localEnvp );
		//OR
		Console::WriteLine( u"[%u]: Environment variable name and the value: %S\n", count++, *localEnvp );

		/* NEXT ITEM IN THE ARRAY OF POINTERS. */
		localEnvp++;

	}; // while ( *localEnvp );

	localEnvp = nullptr;

	Console::Pause( {} );

#pragma endregion


	/*

	EXPLANATIONS.

	About C4996 warning.

	The putenv POSIX function is considerate obsolete.

	Resources like data types, data structures, functions, etc, are improved overtime and some of them, at some point in time, become obsolete. That means that the resource is not essencial or recommned anymore for various reasons, like not having commercial support anymore by compiler, a new resource is available to replace it, etc. The C/C++ compilers uses warnings that helps us to understand and be aware of that situations. The C/C++ compilers have the warnings organized by levels from 0 to N-1, depeding of the compiler implementation practice. Each individual warning is included in some level, and represents a level of severity. We should access the official documentation about warnings to known what the numbers means, because this could be different between compilers.

	The /W3 compiler option (this is not a linker option), is defined by default and because of this, the C4996 warning is emitted by
	Microsoft C/C++ compilers, but this configuration for /W3 can be different depending of Microsoft C/C++ compilers version.

	We should monitor information details using Microsoft official documentation via this link:

	https://docs.microsoft.com/en-us/cpp/build/reference/compiler-option-warning-level?view=vs-2017

	Currently, within Microsoft C/C++ compilers, the level values ranges from 0 to 4, and the level number 1 (one) represents the highest
	level of SEVERITY, and shall be resolved. The level number 2(two) means SIGNIFICANT, that is, this shall be resolved too :).
	The level number 3 (three) PRODUCTION QUALITY, means that will affect the final quality of our product.
	The level number 4 (four) is INFORMATIONAL, means that we can or cannot resolve the issue, depending of criteria of implementation,
	and in general warnings at level 4 does not blocks the compilation or build process, but should be analyzed case-by-case.

	Also, we should monitor the information details about C4996 using Microsoft official documentation via this link:

	https://docs.microsoft.com/en-us/cpp/error-messages/compiler-warnings/compiler-warning-level-3-c4996?view=vs-2017

	Again, technologies are improved constantly, we should be aware that warnings are included and removed overtime. Therefore, warning levels and warning numbers are changed overtime. An advice from my part is that you should, if possible, to store important information to future verification.

	Back to the putenv POSIX function.

	We should use the ANSI ISO C / C++ _putenv, _putenv_s, _wputenv or _wputenv_s instead of putenv POSIX function.
	Instead of _putenv and _wputenv, it is recommeded the use of _putenv_s and _wputenv_s functions that have improved security characteristics.

	*/

	/* warning C4996 */
	/* putenv( "ROGER=Test" ); */

	/*

	HOW TO WORKS WITH ENVIRONMENT VARIABLES?

	To CREATE, MODIFY or REMOVE an environment variable, we should use the  _putenv_s and _wputenv_s functions that have improved security characteristics.

	When an environment variable that does not exists is informed, the environment variable is created.
	The environment variable is created with process scope, that is, it is visible and accessible only by the process.
	These functions does not alter the environment variable with operating system scope, only environment variables with process scope.

	*/

	errno_t result { _wputenv_s( L"ROGER", L"Environment Variables..." ) };
	Console::WriteLine( u"%s\n\n", ( !result ? u"ROGER created for the currently process." : u"Error. ROGER not created for the currently process." ) );
	//wprintf_s( L"%s\n\n", ( !result ? L"ROGER created for the currently process." : L"Error. ROGER not created for the currently process.") );	

	/*

	HOW TO OBTAIN A VALUE OF ENVIRONMENT VARIABLE, IT IS A HARD THING TO DO?

	No, but we need to be aware of details.

	The POSIX function getenv is also considerate obsolete and the warning C4996  is also emitted by Microsoft C/C++ compilers depending of configurations.

	The recommendation is to use getenv_s / _wgetenv / _wgetenv_s ANSI ISO C / C++  functions.
	The use of functions getenv_s / _wgetenv_s is recommended because of improved security characteristics.

	*/

	/* Buffer (memory block) used to store the environment variables. */
	wchar_t* envVariable {};
	size_t requiredSize {};

	/* warning C4996. */
	/* getenv( "ROGER" ); */

	/* Calculates the buffer size for the value of the environment variable. */
	result = _wgetenv_s( &requiredSize, {}, {}, L"roger" );

	/* If _wgetenv_s function succeeded, returns the zero value. */
	if ( !result ) {

		envVariable = ( ( wchar_t* ) malloc( requiredSize * sizeof( wchar_t ) ) );

		/* Shows the uses of Windows API to initialize with zero value the memory block bytes. */
		SecureZeroMemory( envVariable, _msize( envVariable ) );

		/* If _wgetenv_s function succeeded, returns the zero value. */
		if ( !_wgetenv_s( &requiredSize, envVariable, requiredSize, L"ROGER" ) )  Console::WriteLine( u"ROGER : %s\n", envVariable );
		/*wprintf_s( L"ROGER : %s\n", envVariable );*/

		free( envVariable ), envVariable = nullptr;
	};

	/*

	WHICH IS THE MAXIMUM NUMBER OF ENVIRONMENT VARIABLES?

	This value is defined by the _MAX_ENV macro, that is defined in <stdlib.h> and <cstdlib> (C++).
	Currently, the value by the _MAX_ENV macro is defined as showed in this excerpt of header file <stdlib.h> and <cstdlib> (C++):


	// Sizes for buffers used by the getenv/putenv family of functions.
	#define _MAX_ENV 32767


	*/

	Console::WriteLine( u"\n_MAX_ENV: %u\n\n", _MAX_ENV );

	/*

	CAN I REMOVE AN ENVIRONMENT VARIABLE? IS IT EASY?

	Yes.

	To remove an environment variable we should use _putenv_s / _wputenv_s functions and inform as argument value an empty string.

	==> _wputenv_s( L"ROGER", L"" );  // UNICODE
	==> _putenv_s( L"ROGER", "" );  // ANSI

	*/

	if ( !_wputenv_s( L"ROGER", L"" ) ) {
		if ( !_wgetenv_s( &requiredSize, {}, {}, L"ROGER" ) )
			if ( !requiredSize ) Console::WriteLine( u"ROGER "  u"removed.\n\n" );
	};

#pragma region (Bonus sample code) - Demonstration of the use of MessageBox Windows API function.


/*

DESCRIPTION

When you begin working with C++, one of the first questions is how to use Windows API - Application Programming Interface. One way is to start with basic API's that are of common uses in various types of applications. Through these basic API's we can introduce various fundamental Microsoft Windows operating system concepts and resources, Microsoft Windows API's concepts and Microsoft Windows API's practices, without the overload of the information that people talk about when starting work with Microsoft Windows API's and Microsoft Windows API's practices. Also, it is possible present Microsoft Windows operating system concepts via an acceptable sample source code that an individual can change at your own pace, seeing the errors using small changes in source code module and gradually understand what means choose working with C/C++ and Windows API's.

Here we have encapsulated the MessageBox Windows API function in a local custom implementation. The purpose is to offer for you an exercise to experiment the function with support of fundamental and objective documentation. You can read more about in the file MessageBox.cpp, in this project.


SUGGESTION: You can put this block of code inside region, into a global function.


*/
	uint32_t msg { Windows::MessageBox( u"Our Message!!! :)", u"Our Title!!!", MB_OKCANCEL | MB_ICONINFORMATION,
		MB_DEFBUTTON1, MB_TOPMOST ) };

	switch ( msg ) {

		case IDOK: { /*Do something. */ }; break;
		case IDCANCEL: { /*Do something. */ }; break;
		case IDABORT: { /*Do something. */ }; break;
		case IDRETRY: { /*Do something. */ }; break;
		case IDIGNORE: { /*Do something. */ }; break;
		case IDYES: { /*Do something. */ }; break;
		case IDNO: { /*Do something. */ }; break;
		case IDTRYAGAIN: { /*Do something. */ }; break;
		case IDCONTINUE: { /*Do something. */ }; break;
		default: { /*Do something. */ }; break;

	};

#pragma endregion

	Console::Pause( true );

	return 0i32;
};
