/*

AUTHOR: Roger Villela
E-MAIL: RVJ.Education@OpenMind.OnMicrosoft.com
CONTACT: RogerVillelaJournal@OpenMind.OnMicrosoft.com
LINKEDIN: https://www.linkedin.com/in/rogervillela

(EN-US) MATERIAL FOR EXCLUSIVE EDUCATIONAL AND INFORMATIVE USE

The use of this example project and other materials created, provided and presented directly by ROGER VILLELA, hereinafter referred to as the SOLE AUTHOR and SOLE HOLDER of the rights in any present or future context, are dedicated solely to Educational use through courses and other commercial or free products of authorship of the exclusive authors, which the EXCLUSIVE AUTHOR presents and can present throughout the national and international territory through various means of communication and distribution, such as electronic documents, print-outs, social networks and purpose-compatible groups such as blogs and other types of sites for presentation of educational technical content, conferences through products such as Microsoft Skype (Copyright- All rights reserved), Microsoft Teams (copyright-All rights Reserved), Microsoft Skype for Business (copyright-All rights Reserved), and others that are relevant to the educational technical purpose. The EXCLUSIVE AUTHOR is not liable, directly or indirectly, for the use made by third parties of this or other products. The EXCLUSIVE AUTHOR does not implicitly authorize any physical person and person legal, to use their products or their name without the proper commercial and legal contracting. The commercial and legal contracting must follow according to the rules determined in each district, province, principality, kingdom, city, state and country that demonstrate interest. Prior to the commercial and legal rules determined in each geographical context, the terms first formalised by the EXCLUSIVE AUTHOR and which need to be accepted and fulfilled in their entirety for such hiring to be officially recognized by the EXCLUSIVE AUTHOR.

MICROSOFT VISUAL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

		-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
		-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
		-> Use Microsoft Visual Studio 2017 (RTM) as minimum platform.
		-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
		-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
		-> Use the .NET Framework version 4.0 (RTM) as minimum version.
		-> They use the latest version of the .NET Framework (RTM) from the minimum version criterion and as provided.

INTEL PARALLEL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

	-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
	-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
	->  Use Microsoft Visual Studio 2017 (RTM) as minimum platform for the integration environment.
	-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
	-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
	-> Use Intel Parallel Studio 2018 as a minimum platform.
	-> They use the latest version of Intel Parallel Studio from the minimum version criterion and as provided.


INTEL C++ / MICROSOFT VISUAL C++

-> The key code compiles with other versions of Intel C++ / Microsoft Visual C++, provided that there are support for the resources used in the directly related codes and files. But the project file (vcxproj) may be incompatible as a function of changes made through the versions/updates.
-> Compilation options can also vary between versions/updates. If you use another Intel C++ / Microsoft Visual C++ version/update, adjustments may be required.

MICROSOFT WINDOWS SDK

-> The sample projects are always distributed and configured to use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM). However, they are compatible with the Microsoft Windows SDK 10.0.10240.0 onwards.
-> The key code also compiles with other versions of the Windows SDK. However, adaptations may be required as a function of build options and support for features in libraries and header files.

SOFTWARES && TECHNOLOGIES

==> Operating Systems

-> Microsoft Windows 10 (October 2018 Update / a.k.a. 1809)
-> Microsoft Windows 10 (April 2018 Update / a.k.a. 1803)
-> Microsoft Windows 10 (Fall Creators Update)
-> Microsoft Windows 10 (Creators Update)

==> Compilers

-> Microsoft C++
-> Intel C++

==> Platform: Windows OS

-> C++ programming language.
-> Assembly (Intel x86, Intel x64, Intel 64).


==> Platform: CLR (Common Language Runtime)

-> C++/CLI (Common Language Infrastructure) projection.
-> CIL - Common Intermediate Language.
-> C# Programming Language.


==> Platform: WinRT (Windows Runtime)

-> C++/CX (Component Extensions) projection.
-> C++ programming language.


==> Libraries

-> Microsoft UCRT - Universal C Runtime.
-> Microsoft CRT - C Runtime.
-> WinRT Libraries.
-> Windows API's (Application Programming Interfaces).
-> C++ Standard Library.
-> C++ STL - Standard Template Library.
-> STL/CLR Library.
-> BCL - Base Class Library (core set).
-> FCL - Framework Class Library (complete set).

==> Intel Parallel Studio (Intel  C++)

->	2019 (RTM, Update 1).
->	2018 (RTM, Update 3).

==> Microsoft Visual Studio 2019 (Microsoft Visual C++)

-> 16.n.n

==> Microsoft Visual Studio 2017 (Microsoft Visual C++)

-> 15.9.n
-> 15.8.n
-> 15.7.n
-> 15.6.n
-> 15.5.n
-> 15.4.n
-> 15.3.n
-> 15.2.n
-> 15.0.n


==> Microsoft Windows SDK(s) (including updates)

-> 10.0.17763.n (Microsoft Windows 10 version 1809 / a.k.a. October 2018 Update)
-> 10.0.17134.n (Microsoft Windows 10 version 1803 / a.k.a. April 2018 Update)
-> 10.0.16299.n (Microsoft Windows 10  version 1709 / a.k.a. Fall Creators Update)
-> 10.0.15063.n (Microsoft Windows 10 version 1703 / a.k.a. Creators Update)
-> 10.0.15052.n
-> 10.0.14965.n
-> 10.0.14393.n (Microsoft Windows 10 version 1607 / a.k.a. Anniversary Edition)
-> 10.0.10586.n (Microsoft Windows 10)
-> 10.0.10240.n (Microsoft Windows 10)


INTRODUCTION

	void CopyMemory( _In_ PVOID Destination, _In_ const VOID* Source,_In_ SIZE_T Length );

DETAILS

	Copies the content of a memory block to another memory block.

	The function / macro copies the content of a memory block to another memory block. We should not use this function if the addresses of SOURCE and DESTINATION overlaps. The use of CopyMemory() function in case of overlap generates an undefined result. In case of overlap, we should use the MoveMemory() function.

	The first parameter, Destination, must be at least the same size as the argument value informed the for the  Length parameter. Remembering that the argument value informed in the Length parameter is the number of bytes that should be copied.

	The CopyMemory is a macro for RtlCopyMemory, which in turn is a macro for memcpy() function (CRT/UCRT). The memcpy() function is implemented in Assembly programming language and is used inline. Inline means that instead of the function call, the code in the programming language Assembly of the function is included in each occurrence of the function call.

	It is important to note that this function is available since Microsoft Windows XP and Microsoft Windows Server 2003.


*/

#pragma region Include Files
#include <RVJ.Desktop.h>
#pragma endregion

#pragma region Namespaces
using namespace std;
using namespace RVJ::Desktop;
#pragma endregion


#ifdef _WINDOWS_

#if defined( _WIN32 )
typedef uint32_t BaseType;
#elif defined( _WIN64 )
typedef uint64_t BaseType;
#endif

#endif


#pragma region Global values

/* Size of the base type used on the operations. */
constexpr BaseType BaseTypeSize { sizeof( BaseType ) };

#pragma endregion


void wmain() {

#pragma region Example 00

	BaseType y {}, length {};
	BaseType sizeOfBlock {};
	BaseType* newNumbers {};

	BaseType x { 72ui32 };
	BaseType* pointerToX { &x };
	BaseType* pointerToY { &y };

	Console::WriteLine( u"(BEFORE) x: %u\n" "(BEFORE) y: %u\n", x, y );

	/*

	Copy the bytes in the source memory block to the destination memory block.

	*/

	CopyMemory( reinterpret_cast< PVOID >( &y ), reinterpret_cast< const VOID* >( pointerToX ), BaseTypeSize );

	/*

	Doing the same copy operation using different supported C++ syntax options and supported Windows API rules.

	CopyMemory( pointerToY, pointerToX, BaseTypeSize );
	CopyMemory( &y, &x, BaseTypeSize );
	CopyMemory( pointerToY, &x, BaseTypeSize );

	*/

	Console::WriteLine( u"\n(AFTER) x: %u\n" "(AFTER) y: %u\n", x, y );

	pointerToX = nullptr;
	pointerToY = nullptr;

	/*

		If we are using this code in C++/CLI or C++/CX, we should use __nullptr for explicitly indicate native objects.

		pointerToX = __nullptr;
		pointerToY = __nullptr;

	*/

	Console::Pause( {} );

#pragma endregion

#pragma region Example 01

	/*

		Copies the content of the static allocated array (stack based) for a memory block allocated in the UCRT/CRT heap by malloc() function.

	*/

	uint32_t numbers[] { {}, 1ui32, 2ui32, 3ui32, 4ui32, 5ui32, 6ui32, 7ui32, 8ui32, 9ui32 };

	/*

	Calculates the number of elements in the static allocated array.

	*/

	length = ( sizeof( numbers ) / BaseTypeSize );


	/*

	Doing the same operation but using a Microsoft specific function (UCRT/CRT).

	length = _countof( numbers );

	Doing the same operation but using a common expression.

	length = ( sizeof( numbers ) / sizeof( numbers [ 0ui32 ] ) );

	*/

#pragma endregion

#pragma region Example 02

	/*

		The malloc() (UCRT/CRT) function allocates a block of memory in the UCRT/CRT heap.
		But malloc, does not initializes the bytes with some value, with zero or any other. We should explicitly initialize the allocated memory of block, using the Windows API SecureZeroMemory() function or memset() / wmemset() (UCRT / CRT ) functions.


	*/

	newNumbers = reinterpret_cast < uint32_t* >( malloc( length * BaseTypeSize ) );

	/*

		Size of memory block means the number of bytes allocated for that specific block of memory.

		The _msize() (UCRT/CRT) function calculates the number of bytes that there is in a block of memory allocated by one of these UCRT/CRT memory allocation functions:

		- malloc() function.
		- calloc() function.
		- realloc() function.

	*/

	sizeOfBlock = _msize( reinterpret_cast< void* >( newNumbers ) );

	/*

		SecureZeroMemory() is part of the Windows API macros for the memory management. It is in the category "General Memory Functions".

		SecureZeroMemory() is a macro mapped to the RtlSecureZeroMemory() (WinBase.h).
		The implementation of RtlSecureZeroMemory() is inline (WinNT.h).

		The implementation assigns the zero value for every byte in the memory block.

		The SecureZeroMemory() is a modern and more secure version than ZeroMemory() Windows API. We should use SecureZeroMemory() instead of ZeroMemory().

	*/

	SecureZeroMemory( reinterpret_cast< PVOID >( newNumbers ), ( ( SIZE_T ) sizeOfBlock ) );

	/*

	OR

		newNumbers = ( ( BaseType* ) SecureZeroMemory( newNumbers, sizeOfBlock ) );

	*/

	/*

	FillMemory is a macro available in the Windows API. It is in the category "General Memory Functions". 	It is used to fill a block of memory with a specific byte value. 	FillMemory is a mapping for another macro, the RtlFillMemory, that in time, is a mapping for the 	memset (CRT/UCRT) function.  The value can be anyone, because the parameter is of BYTE Windows data type. 	The BYTE Windows data type is a typedef for the unsigned char C++ Standard type:

	typedef unsigned char       BYTE;

	*/

	FillMemory( reinterpret_cast< PVOID* >( newNumbers ), ( ( SIZE_T ) sizeOfBlock ), ( ( BYTE ) '*' ) );

	/*

		Doing the same set operation but using a memset() (UCRT/CRT) function instead of the Windows API.

		newNumbers = reinterpret_cast< BaseType* >( memset( reinterpret_cast< void* >( newNumbers ), ( ( BaseType ) '*' ), ( ( BaseType ) sizeOfBlock ) ) );

	*/

	Console::WriteLine( u"\n(BEFORE) newNumbers \n\n" );

	BaseType index {};

	/* Traversing the memory block and displaying the values. */
	for ( char const * const localBuffer { ( ( char* ) newNumbers ) }; ( index != sizeOfBlock ); index++ )
		Console::WriteLine( u"[%u]: %c\n", index, *( localBuffer + index ) );


	/* The previous content is zero'ed . */
	SecureZeroMemory( reinterpret_cast< PVOID >( newNumbers ), ( ( SIZE_T ) sizeOfBlock ) );

	/* The new values are copied. */
	CopyMemory( reinterpret_cast< PVOID >( newNumbers ), reinterpret_cast< const VOID* >( numbers ), ( ( SIZE_T ) sizeof( numbers ) ) );

	Console::WriteLine( u"\n(AFTER) newNumbers \n\n" ), index = {};

	/* Traversing the memory block and displaying the values. */
	for ( ; ( index != length ); index++ )
		Console::WriteLine( u"[%u]: %u\n", index, ( *( newNumbers + index ) ) );

	/*

		Doing the same operation but using the array syntax to transverse a block of memory.

		Console::WriteLine( u"[%u]: %u\n", index, newNumbers[ index ] );

	*/

	/*

	 Another very important aspect of SecureZeroMemory() Windows API function is that it can be used with any version of the Microsoft Windows operating system implementation because it is generated inline.

	*/
	SecureZeroMemory( reinterpret_cast< PVOID >( newNumbers ), ( ( SIZE_T ) sizeOfBlock ) );

	free( newNumbers ), newNumbers = nullptr;

#pragma endregion

	Console::Pause( true );

	return;
};


