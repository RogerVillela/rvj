/*

AUTHOR: Roger Villela
E-MAIL: RVJ.Education@OpenMind.OnMicrosoft.com
CONTACT: RogerVillelaJournal@OpenMind.OnMicrosoft.com
LINKEDIN: https://www.linkedin.com/in/rogervillela

(EN-US) MATERIAL FOR EXCLUSIVE EDUCATIONAL AND INFORMATIVE USE

The use of this example project and other materials created, provided and presented directly by ROGER VILLELA, hereinafter referred to as the SOLE AUTHOR and SOLE HOLDER of the rights in any present or future context, are dedicated solely to Educational use through courses and other commercial or free products of authorship of the exclusive authors, which the EXCLUSIVE AUTHOR presents and can present throughout the national and international territory through various means of communication and distribution, such as electronic documents, print-outs, social networks and purpose-compatible groups such as blogs and other types of sites for presentation of educational technical content, conferences through products such as Microsoft Skype (Copyright- All rights reserved), Microsoft Teams (copyright-All rights Reserved), Microsoft Skype for Business (copyright-All rights Reserved), and others that are relevant to the educational technical purpose. The EXCLUSIVE AUTHOR is not liable, directly or indirectly, for the use made by third parties of this or other products. The EXCLUSIVE AUTHOR does not implicitly authorize any physical person and person legal, to use their products or their name without the proper commercial and legal contracting. The commercial and legal contracting must follow according to the rules determined in each district, province, principality, kingdom, city, state and country that demonstrate interest. Prior to the commercial and legal rules determined in each geographical context, the terms first formalised by the EXCLUSIVE AUTHOR and which need to be accepted and fulfilled in their entirety for such hiring to be officially recognized by the EXCLUSIVE AUTHOR.

MICROSOFT VISUAL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

		-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
		-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
		-> Use Microsoft Visual Studio 2017 (RTM) as minimum platform.
		-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
		-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
		-> Use the .NET Framework version 4.0 (RTM) as minimum version.
		-> They use the latest version of the .NET Framework (RTM) from the minimum version criterion and as provided.

INTEL PARALLEL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

	-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
	-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
	->  Use Microsoft Visual Studio 2017 (RTM) as minimum platform for the integration environment.
	-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
	-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
	-> Use Intel Parallel Studio 2018 as a minimum platform.
	-> They use the latest version of Intel Parallel Studio from the minimum version criterion and as provided.


INTEL C++ / MICROSOFT VISUAL C++

-> The key code compiles with other versions of Intel C++ / Microsoft Visual C++, provided that there are support for the resources used in the directly related codes and files. But the project file (vcxproj) may be incompatible as a function of changes made through the versions/updates.
-> Compilation options can also vary between versions/updates. If you use another Intel C++ / Microsoft Visual C++ version/update, adjustments may be required.

MICROSOFT WINDOWS SDK

-> The sample projects are always distributed and configured to use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM). However, they are compatible with the Microsoft Windows SDK 10.0.10240.0 onwards.
-> The key code also compiles with other versions of the Windows SDK. However, adaptations may be required as a function of build options and support for features in libraries and header files.

SOFTWARES && TECHNOLOGIES

==> Operating Systems

-> Microsoft Windows 10 (October 2018 Update / a.k.a. 1809)
-> Microsoft Windows 10 (April 2018 Update / a.k.a. 1803)
-> Microsoft Windows 10 (Fall Creators Update)
-> Microsoft Windows 10 (Creators Update)

==> Compilers

-> Microsoft C++
-> Intel C++

==> Platform: Windows OS

-> C++ programming language.
-> Assembly (Intel x86, Intel x64, Intel 64).


==> Platform: CLR (Common Language Runtime)

-> C++/CLI (Common Language Infrastructure) projection.
-> CIL - Common Intermediate Language.
-> C# Programming Language.


==> Platform: WinRT (Windows Runtime)

-> C++/CX (Component Extensions) projection.
-> C++ programming language.


==> Libraries

-> Microsoft UCRT - Universal C Runtime.
-> Microsoft CRT - C Runtime.
-> WinRT Libraries.
-> Windows API's (Application Programming Interfaces).
-> C++ Standard Library.
-> C++ STL - Standard Template Library.
-> STL/CLR Library.
-> BCL - Base Class Library (core set).
-> FCL - Framework Class Library (complete set).

==> Intel Parallel Studio (Intel  C++)

->	2019 (RTM, Update 1).
->	2018 (RTM, Update 3).

==> Microsoft Visual Studio 2019 (Microsoft Visual C++)

-> 16.n.n

==> Microsoft Visual Studio 2017 (Microsoft Visual C++)

-> 15.9.n
-> 15.8.n
-> 15.7.n
-> 15.6.n
-> 15.5.n
-> 15.4.n
-> 15.3.n
-> 15.2.n
-> 15.0.n


==> Microsoft Windows SDK(s) (including updates)

-> 10.0.17763.n (Microsoft Windows 10 version 1809 / a.k.a. October 2018 Update)
-> 10.0.17134.n (Microsoft Windows 10 version 1803 / a.k.a. April 2018 Update)
-> 10.0.16299.n (Microsoft Windows 10  version 1709 / a.k.a. Fall Creators Update)
-> 10.0.15063.n (Microsoft Windows 10 version 1703 / a.k.a. Creators Update)
-> 10.0.15052.n
-> 10.0.14965.n
-> 10.0.14393.n (Microsoft Windows 10 version 1607 / a.k.a. Anniversary Edition)
-> 10.0.10586.n (Microsoft Windows 10)
-> 10.0.10240.n (Microsoft Windows 10)


INTRODUCTION

	void MoveMemory( _In_ PVOID Destination, _In_ const VOID *Source, _In_ SIZE_T Length );

DETAILS

	Moves the bytes from one memory block to another memory block.

	The Length parameter must have the total numbers of bytes that must be moved from Source to Destination.
	The Destination block of memory must be large enough to store the numbers of bytes informed as argument value.

	MoveMemory is a macro mapped to another macro, RltMoveMemory.
	The RtlMoveMemory macro is mapped to the memmove function, that in fact do the task of moving the bytes betweem memory blocks..
	The memmove function is implemented in Assembly language, and is used inline.
	Inline means that instead of the function call, the assembly code is inserted in every place where a function call was made.

	If the Source and Destination overlapped, uses the MoveMemory() function and not CopyMemory() function.
	If the Source and Destination overlapped, the use of CopyMemory() function generates undefined results.


	The MoveMemory() function is available since Microsoft Windows XP e Microsoft Windows Server 2003.



*/

#ifdef __INTEL_COMPILER
#pragma warning( disable: 1079; )
#endif

#pragma region Include Files
#include <RVJ.Desktop.h>
#pragma endregion

#pragma region Namespaces
using namespace std;
using namespace RVJ::Desktop;
#pragma endregion


#pragma region Base type and base type size
typedef uint32_t BaseType;
constexpr uint32_t BaseTypeSize { sizeof( uint32_t ) };
#pragma endregion

void PrintValues( const uint32_t* const list = {}, uint32_t limit = {}, uint32_t start = {} ) {

	if ( list != nullptr )	for ( ; ( start != limit ); start++ ) 	Console::WriteLine( u"Value[%u]: %u\n", start, *( list + start ) );

	return;
};

void wmain() {

#pragma region Example 0

	BaseType y {};
	BaseType x { 72ui32 };

	Console::WriteLine( u"(BEFORE) x, y : %u, %u\n", x, y );

	MoveMemory( &y, &x, BaseTypeSize );

	Console::WriteLine( u"(AFTER) x, y : %u, %u\n", x, y );

	Console::Pause( {} );

#pragma endregion	

#pragma region Example 1 - Typical move operation.

	BaseType numbers[] { {}, 1ui32, 2ui32, 3ui32, 4ui32, 5ui32, 6ui32, 7ui32, 8ui32, 9ui32 };

	/*
	Total numbers of bytes for all elements in array.
	*/
	BaseType totalOfBytes { sizeof( numbers ) };

	/*
	Total number of elements.
	*/
	constexpr BaseType Length { _countof( numbers ) };
	/*constexpr BaseType Length{ ( sizeof( numbers ) / BaseTypeSize ) };*/

	/*
	Using the malloc (UCRT/CRT) function to allocate a new block of memory.
	*/
	BaseType* newNumbers { ( reinterpret_cast< BaseType* >( malloc( totalOfBytes ) ) ) };

	/*
	Zero'ed tbe new block of memory allocated with malloc (UCRT/CRT) function.
	*/
	newNumbers = ( reinterpret_cast< BaseType* >( SecureZeroMemory( newNumbers, totalOfBytes ) ) );

	Console::WriteLine( u"(BEFORE) newNumbers\n\n" );

	PrintValues( newNumbers, Length );

	Console::Pause( {} );

	/*

		The Destination parameter indicates for which buffer the bytes must be moved.
		The Source parameter indicates from where the bytes must be copied.
		The Length parameter indicates the TOTAL OF BYTES that must be moved from Source to Destination.

		This example move the first 20 bytes from numbers to newNumbers.

	*/

	MoveMemory( reinterpret_cast< PVOID >( newNumbers ), reinterpret_cast< const VOID* >( numbers ), ( ( SIZE_T ) ( Length >> 1ui32 ) ) );

	Console::WriteLine( u"(AFTER) newNumbers\n\n" );

	PrintValues( newNumbers, ( Length >> 1ui32 ) );

	Console::Pause( {} );

	/*

		Informing a different start position as source.


		This example moves the items with values between 6 through 9, from numbers to newNumbers.

	*/

	/*
	Moves the second half of the Source to the second half of Destination.
	*/
	BaseType position { Length >> 1ui32 };
	MoveMemory( ( newNumbers + position ), ( numbers + position ), ( totalOfBytes >> 1ui32 ) );

	/*
	Shows the list with the new values.
	*/
	PrintValues( newNumbers, Length );

	free( newNumbers );
	newNumbers = nullptr;

	Console::Pause( {} );

#pragma endregion

#pragma region Example 2 - Overlapped memory blocks.

	HANDLE hProcessHeap { GetProcessHeap() };
	BaseType* source { reinterpret_cast< BaseType* >( HeapAlloc( hProcessHeap, HEAP_ZERO_MEMORY, 400ui32 ) ) };
	BaseType heapSize { ( ( BaseType ) HeapSize( hProcessHeap, {}, source ) ) };

	source = reinterpret_cast< BaseType* > ( SecureZeroMemory( source, heapSize ) );

	/* Shows the memory content, before the move operation. */

	/* Source and destination are the same. */
	BaseType* destination { source };

	/* Check the results by yourself. */
	RtlMoveMemory( source, source, heapSize );

	if FAILED( HeapFree( hProcessHeap, {}, source ) )  Console::LastError();

	source = nullptr; heapSize = {}; hProcessHeap = nullptr;

#pragma endregion

	Console::Pause( true );

	return;
};


