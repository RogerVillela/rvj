/*

AUTHOR: Roger Villela
E-MAIL: RVJ.Education@OpenMind.OnMicrosoft.com
CONTACT: RogerVillelaJournal@OpenMind.OnMicrosoft.com
LINKEDIN: https://www.linkedin.com/in/rogervillela

(EN-US) MATERIAL FOR EXCLUSIVE EDUCATIONAL AND INFORMATIVE USE

The use of this example project and other materials created, provided and presented directly by ROGER VILLELA, hereinafter referred to as the SOLE AUTHOR and SOLE HOLDER of the rights in any present or future context, are dedicated solely to Educational use through courses and other commercial or free products of authorship of the exclusive authors, which the EXCLUSIVE AUTHOR presents and can present throughout the national and international territory through various means of communication and distribution, such as electronic documents, print-outs, social networks and purpose-compatible groups such as blogs and other types of sites for presentation of educational technical content, conferences through products such as Microsoft Skype (Copyright- All rights reserved), Microsoft Teams (copyright-All rights Reserved), Microsoft Skype for Business (copyright-All rights Reserved), and others that are relevant to the educational technical purpose. The EXCLUSIVE AUTHOR is not liable, directly or indirectly, for the use made by third parties of this or other products. The EXCLUSIVE AUTHOR does not implicitly authorize any physical person and person legal, to use their products or their name without the proper commercial and legal contracting. The commercial and legal contracting must follow according to the rules determined in each district, province, principality, kingdom, city, state and country that demonstrate interest. Prior to the commercial and legal rules determined in each geographical context, the terms first formalised by the EXCLUSIVE AUTHOR and which need to be accepted and fulfilled in their entirety for such hiring to be officially recognized by the EXCLUSIVE AUTHOR.

MICROSOFT VISUAL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

		-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
		-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
		-> Use Microsoft Visual Studio 2017 (RTM) as minimum platform.
		-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
		-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
		-> Use the .NET Framework version 4.0 (RTM) as minimum version.
		-> They use the latest version of the .NET Framework (RTM) from the minimum version criterion and as provided.

INTEL PARALLEL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

	-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
	-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
	->  Use Microsoft Visual Studio 2017 (RTM) as minimum platform for the integration environment.
	-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
	-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
	-> Use Intel Parallel Studio 2018 as a minimum platform.
	-> They use the latest version of Intel Parallel Studio from the minimum version criterion and as provided.


INTEL C++ / MICROSOFT VISUAL C++

-> The key code compiles with other versions of Intel C++ / Microsoft Visual C++, provided that there are support for the resources used in the directly related codes and files. But the project file (vcxproj) may be incompatible as a function of changes made through the versions/updates.
-> Compilation options can also vary between versions/updates. If you use another Intel C++ / Microsoft Visual C++ version/update, adjustments may be required.

MICROSOFT WINDOWS SDK

-> The sample projects are always distributed and configured to use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM). However, they are compatible with the Microsoft Windows SDK 10.0.10240.0 onwards.
-> The key code also compiles with other versions of the Windows SDK. However, adaptations may be required as a function of build options and support for features in libraries and header files.

SOFTWARES && TECHNOLOGIES

==> Operating Systems

-> Microsoft Windows 10 (October 2018 Update / a.k.a. 1809)
-> Microsoft Windows 10 (April 2018 Update / a.k.a. 1803)
-> Microsoft Windows 10 (Fall Creators Update)
-> Microsoft Windows 10 (Creators Update)

==> Compilers

-> Microsoft C++
-> Intel C++

==> Platform: Windows OS

-> C++ programming language.
-> Assembly (Intel x86, Intel x64, Intel 64).


==> Platform: CLR (Common Language Runtime)

-> C++/CLI (Common Language Infrastructure) projection.
-> CIL - Common Intermediate Language.


==> Platform: WinRT (Windows Runtime)

-> C++/CX (Component Extensions) projection.
-> C++ programming language.


==> Libraries

-> Microsoft UCRT - Universal C Runtime.
-> Microsoft CRT - C Runtime.
-> WinRT Libraries.
-> Windows API's (Application Programming Interfaces).
-> C++ Standard Library.
-> C++ STL - Standard Template Library.
-> STL/CLR Library.
-> BCL - Base Class Library (core set).
-> FCL - Framework Class Library (complete set).

==> Intel Parallel Studio (Intel  C++)

->	2019 (RTM, Update 1).
->	2018 (RTM, Update 3).

==> Microsoft Visual Studio 2017 (Microsoft Visual C++)

-> 15.9.n
-> 15.8.n
-> 15.7.n
-> 15.6.n
-> 15.5.n
-> 15.4.n
-> 15.3.n
-> 15.2.n
-> 15.0.n

==> Microsoft Windows SDK(s) (including updates)

-> 10.0.17763.n (Microsoft Windows 10 October 2018 Update / a.k.a. 1809)
-> 10.0.17134.n (Microsoft Windows 10 April 2018 Update / a.k.a. 1803)
-> 10.0.16299.n (Microsoft Windows 10 Fall Creators Update)
-> 10.0.15063.n (Microsoft Windows 10 Creators Update)
-> 10.0.15052.n
-> 10.0.14965.n
-> 10.0.14393.n
-> 10.0.10586.n
-> 10.0.10240.n



INTRODUCTION

	ANSI/ISO signature:

	int main( int argc, char* argv[] );

	 Or a compatible signature (not ANSI/ISO), but supported by modern compilers:

	int main( int32_t argc, int8_t* argv[] );

DETAILS

	ANSI C iplementation of main() function.

	How to obtain the values informed as argument values in command line?


	The ANSI/ISO C / C++  standards defines two signatures for main() function:

	1- int main() {};
	2- int main( int argc, char* argv[] ) {};

	The argv is declared as a vector (single-dimensional array) of pointers for a string of char data type.

	The parameter arc means ARGUMENT COUNT, the number of argument values informed in the command line.

	The parameter argv means ARGUMENT VARIABLES and are the  ARGUMENT VALUES informed at command line.
	For access the values, we uses a loop and obtain item-by-item.

	At command line the argument values are separated by ONE OR MORE SPACE VALUES (blank spaces, typically).

	With the C or C++ programming languages, we can access the values using argv as it is declared, that is, as a pointer or using
	the syntax of array.


*/

#ifdef __INTEL_COMPILER
#pragma warning( disable: 1079; )
#endif

#pragma region Header files

/*

	HEADER FILE NAMES

	We need to include one or more header files to obtain access to the components like data types, functions, class types, etc.

	Before the C programming language standardization, the header files extensions were a confusion.
	Implementations have used different extensions like .h, .hpp or .hxx, for example.
	Currently, the implementations that are in conformance with ANSI / ISO C e C++ does not have an extension.
	Beside of this, the header files with extensions are still valid, used and supported by commercial compilers.
	For example, the Boost library (boost.org) is an user of .hpp extension for header files and the Microsoft Visual C++
	and recognizes them as header files. The same is valid for Intel C/C++ products.

*/

#include <RVJ.Desktop.h>
#pragma endregion

#pragma region Namespaces
using namespace std;
using namespace RVJ::Desktop;
#pragma endregion


/* Base type. */
//typedef int8_t BaseType;
//typedef char BaseType;
typedef char16_t BaseType;
//typedef char32_t BaseType;

/* Size of base type, IN BYTES. */
constexpr uint32_t BaseTypeSize { sizeof( BaseType ) };

/* Maximum number of CHARACTERS. */
constexpr uint32_t BufferSize { 2048ui32 };

/*
int main( int32_t argc ) {
*/
int main( int32_t argc, int8_t* argv [] ) {


#pragma region Scenario 00 - Tips of use of Microsoft UCRT / CRT elements and Microsoft Windows API elements. 

/*

	Presents some details about the Microsoft UCRT functions and Microsoft Windows API per si.

	Microsoft UCRT - Universal C-Runtime.

	-> _msize function: returns the size in bytes of a memory block allocated in the heap.
	This function only works with memory blocks allocated with one of these functions:

	-> calloc
	-> malloc
	-> realloc

	This function also validates the argument value.
	If the argument value is nullptr / __nullptr, the function assigns the EINVAL value for errno and returns the value -1 (minus one).


	-> calloc function: allocates a memory block on UCRT heap and assigns the zero value for each byte in the new allocated memory block.

	The term "zeroed" or "zero-ed" is also used in documentations to describes this kind of action of initialization of the bytes on a memory block. This is a common technique within any professional and commercial compiler, and implemented even in managed environment like the VES - Virtual Execution System of CLR - Common Language Runtime and specialized non-managed execution runtimes like WinRT - Windows Runtime.

	-> free function: releases the allocated memory block on UCRT heap.

	Microsoft Windows API

	-> StringCchPrintfEx function: write formatted data to the specified buffer. The buffer is an allocated memory block of the BaseType, in this example the BaseType is one of the following fundamental built-in data types int8_t, char, char16_t or char32_t.

	This Windows API function is part of a set of functions named "String Safe Functions", that are part of the Microsoft Windows API.
	Currently, this API is officially supported by Microsoft on Microsoft Windows XP SP2, Microsoft Windows Server 2003 with SP1 for desktop applications and UWP - Universal Windows Platform. The header file is <strsafe.h>.  If you needs more commercial details, you should contact Microsoft. The use of these specialized functions is recommend instead of certain UCRT / CRT string functions.
	For example, the used of StringCchPrintfEx function if recommended instead of the following functions:

	-> sprintf
	-> swprintf
	-> _stprintf
	-> wsprintf
	-> wnsprintf
	-> _snprintf
	-> _snwprintf
	-> _sntprintf

	The string safe functions of Windows API are declared in the <strsafe.h> header file.
	These functions validate the arguments by applying various rules. These functions also has much more parameters and are  not so easy to use  at the first experience, but with time this confusion disappears.

	When learning about these functions, my recommendation is to create small projects like this that we are working on, and write comments about the use of parameters, using scenarios explaining the rules and combinations that are more relevant at first moment of use. These functions specialized in string manipulation also use the specialized macros for the return, the SUCCEEDED and FAILED.
	Originally SUCCEEDED and FAILED are part of Microsoft COM - Component Object Model environment, but not restricted to it.

	- The macro SUCCEEDED is used to test if the operation was performed without failure.
	- The FAILED macro is used to test if the operation has failed.

	When we want only test if the operation was performed without failure without the use of SUCCEEDED and FAILED macros,
	we can test the result against S_OK value.

	Here are the definitions of macros that are on strsafe.h header file:

	#define SUCCEEDED(hr)   (((HRESULT)(hr)) >= 0)
	#define FAILED(hr)      (((HRESULT)(hr)) < 0)
	#define S_OK            ((HRESULT)0L)

	We will not talk about these string safe functions in this EntryPoint solution projects.
	We will talk about these string safe functions in another solution with dedicated projects for this subject.
	But, in the mean time if you want to start to learn about the StringCchPrintfEx function and others of the <strsafe.h> header file you can
	access via this URL:

	https://docs.microsoft.com/en-us/windows/desktop/api/strsafe/nf-strsafe-stringcchprintfexw

	We must be aware that these functions, as many others of Microsoft Windows API, has implementations with support for ANSI and for UNICODE. They are named using this convention:

	- StringCchPrintfExA ( Functions with support for ANSI have the A letter at end of function name. ).
	- StringCchPrintfExW ( Functions with support for UNICODE have the W (wide) letter at end of function name. ).

*/


#pragma endregion

	BaseType*  destination { ( BaseType* ) calloc( BufferSize, BaseTypeSize ) };
	BaseType* sourceAddress { destination };
	BaseType** destinationEnd { &destination };

	uint32_t index {};
	uint32_t blockSize { _msize( destination ) };
	uint32_t remaining {};
	bool operationResult { true }; /* The argument count is always ( argc > 0i32 ). */

	/*

	Runs through the argv (informed values) using argc (number of arguments) as the limit.
	The StringCchPrintfEx function copy ALL INDIVIDUAL CHARS from source memory block to the destination memory block.
	In this example, the source memory block is the argv.

	*/

#pragma region Examples of not so easy to read implementations.

	while ( ( ( index != argc ) && SUCCEEDED( StringCchPrintfEx(
		reinterpret_cast< LPTSTR >( destination ), BufferSize,
		reinterpret_cast < LPTSTR* > ( destinationEnd ), &remaining, STRSAFE_NULL_ON_FAILURE, L"argv[ %d ]: %S\n", index, argv [ index ] )
		) ) ) index++;

	Console::WriteLine( u"Buffer content: %s", ( ( destination = sourceAddress ) != nullptr ) ? destination : u"ERROR!!!" );

		/*

		The same implementation as before, but using Using S_OK and not SUCCEEDED or FAILED macros.
	while ( ( ( index != argc ) && ( StringCchPrintfEx(
		reinterpret_cast < LPTSTR > ( destination ), BufferSize,
		reinterpret_cast < LPTSTR* > ( destinationEnd ), &remaining, STRSAFE_NULL_ON_FAILURE, L"argv[ %d ]: %S\n", index, argv [ index ] ) == S_OK
		) ) ) index++;

		*/


#pragma endregion

#pragma region  A much easy to read implementation.

	while ( ( ( index != argc ) && operationResult ) ) {

		operationResult = SUCCEEDED(
			StringCchPrintfEx(
			reinterpret_cast< LPTSTR > ( destination ), BufferSize,
			reinterpret_cast< LPTSTR* > ( destinationEnd ), &remaining, STRSAFE_NULL_ON_FAILURE, L"argv[ %d ]: %S\n", index, argv [ index ] )
		);

		index++;

	};

	/*

	The same implementation as before, but using using S_OK and not SUCCEEDED or FAILED macros.

	while ( ( ( index != argc ) && operationResult ) ) {

		operationResult = (
			StringCchPrintfEx(
			reinterpret_cast< LPTSTR > ( destination ), BufferSize,
			reinterpret_cast< LPTSTR* > ( destinationEnd ), &remaining, STRSAFE_NULL_ON_FAILURE, L"argv[ %d ]: %S\n", index, argv [ index ] ) == S_OK
		);

		index++;

	};
	*/

#pragma endregion

	Console::WriteLine( u"Buffer content: %s", ( ( destination = sourceAddress ) != nullptr ) ? destination : u"ERROR!!!" );


	/*

	IMPORTANT!!!

	When using memory blocks, it is common that functions moves the pointer through the set of memory addresses and returns a different
	memory address, or changing the argument value using the same pointer variable informed as parameter.
	If we need to preserve the original argument value informed with the pointer variable, it is necessary creates a copy before calling the function. 	In this example, at beginning of main() function, the sourceAddress pointer variable has been created and initialized with the destinaton pointer variable. For example, the Windows API SecureZeroMemory function does not changes the original value and uses this programming technic. This is a common technic used by Microsoft Windows API ands API's of operating systems in general.

	Another important aspect to be highlighted is the extensive use of macros and typedefs by Windows API, we should be familiarized with this. 	The SecureZeroMemory is a macro for the real function, in this case, the RtlSecureZeroMemory. A macro is used as an "alias", to create an indirection level of access to the real name of the element, like a data type or function for example. With this, we can have a PUBLIC name and preserve an internal name. If at some moment we need to change the internal name, source code that are using the public name will not be direct affected. But the macro is also used for creating a name (public or not) for complex expressions, simplifying the use.

	#define SecureZeroMemory RtlSecureZeroMemory

	In this example we does not have used some of the STRSAFE_ prefixed data types defined in the strsafe.h header file because are  deprecated. If we select the name and press F12 (Go To Definition) the header file with the type will be opened and we can take a look at typedef for this data type. Also, it is common that one typedef points to another typedef, creating a cascade of indirections. The uses of typedef (type definition) is another technic for creating another name for an element. But typedefs can be used only with DATA TYPES, and cannot be used for the creates another name for  expressions, like we can do with macros. The typedef can be used with fundamental data types, class types, struct types and others elements that are defined by C++ programming language as data types.

	The use of macros and typedefs is one of the technics used by Microsoft Windows API and APIs of operating systems in general.

	typedef _Null_terminated_ char* STRSAFE_LPSTR;
	typedef _Null_terminated_ const char* STRSAFE_LPCSTR;
	typedef _Null_terminated_ wchar_t* STRSAFE_LPWSTR;
	typedef _Null_terminated_ const wchar_t* STRSAFE_LPCWSTR;
	typedef _Null_terminated_ const wchar_t UNALIGNED* STRSAFE_LPCUWSTR;

	*/


	/*

	DEPRECATED STRSAFE_ typedefs

	Some of typedefs for the String safe functions are deprecated and Microsoft recommends the use of non STRSAFE_ prefixed typedefs.

	This is an excerpt of the header file strsafe.h:


	// Deprecated, use the non STRSAFE_ prefixed types instead (e.g. LPSTR or PSTR) as they are the same as these.
	typedef _Null_terminated_ char* STRSAFE_LPSTR;
	typedef _Null_terminated_ const char* STRSAFE_LPCSTR;
	typedef _Null_terminated_ wchar_t* STRSAFE_LPWSTR;
	typedef _Null_terminated_ const wchar_t* STRSAFE_LPCWSTR;
	typedef _Null_terminated_ const wchar_t UNALIGNED* STRSAFE_LPCUWSTR;

	// Deprecated, use the base types instead.
	// Strings where the string is NOT guaranteed to be null terminated (does not have _Null_terminated_).
	typedef  const char* STRSAFE_PCNZCH;
	typedef  const wchar_t* STRSAFE_PCNZWCH;
	typedef  const wchar_t UNALIGNED* STRSAFE_PCUNZWCH;


	*/

	/*

	To avoid any surprises, is better call _msize function again to get the memory block size.

	*/
	free( SecureZeroMemory( destination, _msize( destination ) ) ), destination = nullptr, destinationEnd = nullptr;

	Console::Pause( true );

	/*

	The ANSI ISO C/C++  standard defines that exists an implicit return 0;.
	A compiler in conformance with ANSI ISO C/C++  standard shall support this implicit return 0;.
	That means, if we cannot explicitly write a return 0; on the end of main() / wmain() function, a compiler in conformance with
	ANSI / ISO C / C++ standard, shall include.

	The  Microsoft C/C++ and Intel C/C++ implements this ANSI/ISO C / C++ feature.

	return 0i32;

	*/

};