/*

AUTHOR: Roger Villela
E-MAIL: RVJ.Education@OpenMind.OnMicrosoft.com
CONTACT: RogerVillelaJournal@OpenMind.OnMicrosoft.com
LINKEDIN: https://www.linkedin.com/in/rogervillela

(EN-US) MATERIAL FOR EXCLUSIVE EDUCATIONAL AND INFORMATIVE USE

The use of this example project and other materials created, provided and presented directly by ROGER VILLELA, hereinafter referred to as the SOLE AUTHOR and SOLE HOLDER of the rights in any present or future context, are dedicated solely to Educational use through courses and other commercial or free products of authorship of the exclusive authors, which the EXCLUSIVE AUTHOR presents and can present throughout the national and international territory through various means of communication and distribution, such as electronic documents, print-outs, social networks and purpose-compatible groups such as blogs and other types of sites for presentation of educational technical content, conferences through products such as Microsoft Skype (Copyright- All rights reserved), Microsoft Teams (copyright-All rights Reserved), Microsoft Skype for Business (copyright-All rights Reserved), and others that are relevant to the educational technical purpose. The EXCLUSIVE AUTHOR is not liable, directly or indirectly, for the use made by third parties of this or other products. The EXCLUSIVE AUTHOR does not implicitly authorize any physical person and person legal, to use their products or their name without the proper commercial and legal contracting. The commercial and legal contracting must follow according to the rules determined in each district, province, principality, kingdom, city, state and country that demonstrate interest. Prior to the commercial and legal rules determined in each geographical context, the terms first formalised by the EXCLUSIVE AUTHOR and which need to be accepted and fulfilled in their entirety for such hiring to be officially recognized by the EXCLUSIVE AUTHOR.

MICROSOFT VISUAL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

		-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
		-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
		-> Use Microsoft Visual Studio 2017 (RTM) as minimum platform.
		-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
		-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
		-> Use the .NET Framework version 4.0 (RTM) as minimum version.
		-> They use the latest version of the .NET Framework (RTM) from the minimum version criterion and as provided.

INTEL PARALLEL STUDIO

-> The solutions, projects, sample codes, support files required, codes that are integrally or partially included in the newsletter text as part of each edition of the ROGERVILLELA JOURNAL are constructed according to the following minimum criteria:

	-> Use Microsoft Windows 10 creators Update (RTM) as minimum platform.
	-> They use the latest version of Microsoft Windows 10 (RTM) as provided.
	->  Use Microsoft Visual Studio 2017 (RTM) as minimum platform for the integration environment.
	-> They use the latest version of Microsoft Visual Studio 2017 (RTM) as provided.
	-> Use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM) as provided.
	-> Use Intel Parallel Studio 2018 as a minimum platform.
	-> They use the latest version of Intel Parallel Studio from the minimum version criterion and as provided.


INTEL C++ / MICROSOFT VISUAL C++

-> The key code compiles with other versions of Intel C++ / Microsoft Visual C++, provided that there are support for the resources used in the directly related codes and files. But the project file (vcxproj) may be incompatible as a function of changes made through the versions/updates.
-> Compilation options can also vary between versions/updates. If you use another Intel C++ / Microsoft Visual C++ version/update, adjustments may be required.

MICROSOFT WINDOWS SDK

-> The sample projects are always distributed and configured to use the latest version of the Microsoft Windows SDK (RTM) for Microsoft Windows 10 (RTM). However, they are compatible with the Microsoft Windows SDK 10.0.10240.0 onwards.
-> The key code also compiles with other versions of the Windows SDK. However, adaptations may be required as a function of build options and support for features in libraries and header files.

SOFTWARES && TECHNOLOGIES

==> Operating Systems

-> Microsoft Windows 10 (October 2018 Update / a.k.a. 1809)
-> Microsoft Windows 10 (April 2018 Update / a.k.a. 1803)
-> Microsoft Windows 10 (Fall Creators Update)
-> Microsoft Windows 10 (Creators Update)

==> Compilers

-> Microsoft C++
-> Intel C++

==> Platform: Windows OS

-> C++ programming language.
-> Assembly (Intel x86, Intel x64, Intel 64).


==> Platform: CLR (Common Language Runtime)

-> C++/CLI (Common Language Infrastructure) projection.
-> CIL - Common Intermediate Language.
-> C# Programming Language.


==> Platform: WinRT (Windows Runtime)

-> C++/CX (Component Extensions) projection.
-> C++ programming language.


==> Libraries

-> Microsoft UCRT - Universal C Runtime.
-> Microsoft CRT - C Runtime.
-> WinRT Libraries.
-> Windows API's (Application Programming Interfaces).
-> C++ Standard Library.
-> C++ STL - Standard Template Library.
-> STL/CLR Library.
-> BCL - Base Class Library (core set).
-> FCL - Framework Class Library (complete set).

==> Intel Parallel Studio (Intel  C++)

->	2019 (RTM, Update 1).
->	2018 (RTM, Update 3).

==> Microsoft Visual Studio 2019 (Microsoft Visual C++)

-> 16.n.n

==> Microsoft Visual Studio 2017 (Microsoft Visual C++)

-> 15.9.n
-> 15.8.n
-> 15.7.n
-> 15.6.n
-> 15.5.n
-> 15.4.n
-> 15.3.n
-> 15.2.n
-> 15.0.n


==> Microsoft Windows SDK(s) (including updates)

-> 10.0.17763.n (Microsoft Windows 10 version 1809 / a.k.a. October 2018 Update)
-> 10.0.17134.n (Microsoft Windows 10 version 1803 / a.k.a. April 2018 Update)
-> 10.0.16299.n (Microsoft Windows 10  version 1709 / a.k.a. Fall Creators Update)
-> 10.0.15063.n (Microsoft Windows 10 version 1703 / a.k.a. Creators Update)
-> 10.0.15052.n
-> 10.0.14965.n
-> 10.0.14393.n (Microsoft Windows 10 version 1607 / a.k.a. Anniversary Edition)
-> 10.0.10586.n (Microsoft Windows 10)
-> 10.0.10240.n (Microsoft Windows 10)


INTRODUCTION


DETAILS


	This function does not differentiate between client and server implementations of Microsoft Windows.

*/

#ifdef __INTEL_COMPILER
#pragma warning( disable: 1079; )
#endif

#pragma region Header Files
#include <RVJ.Desktop.h>
#include "Example00.h"
#pragma endregion

#pragma region Namespaces
using namespace std;
#pragma endregion


LRESULT CALLBACK WndProc( HWND hWindow, UINT message, WPARAM wParam, LPARAM lParam ) {

	CONST_OR_CONSTEXPR SIZE_T MaxClassNameSize { 80ui32 };
	CONST_OR_CONSTEXPR WCHAR* ButtonClassName { L"Button" };
	CONST_OR_CONSTEXPR char16_t* const defaultWindowText { u"Hello, Microsoft Windows 10!" };

	LRESULT processResult {};

	switch ( message ) {

		case WM_CREATE: {

			LPWSTR windowClassName { reinterpret_cast< LPWSTR >( HeapAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, MaxClassNameSize ) ) };
			bool validClassName { ( GetClassName( hWindow, windowClassName, MaxClassNameSize ) > 0i32 ) };

			HeapFree( GetProcessHeap(), {}, reinterpret_cast< LPVOID >( windowClassName ) );
			windowClassName = nullptr;

		};
						break;


		case WM_SIZE: {

			RECT clientRect {};

			GetClientRect( hWindow, &clientRect );

			EnumChildWindows( hWindow, &ManagedChildWindows, ( LPARAM ) &clientRect );

			processResult = FALSE;

		}; break;

		case WM_PARENTNOTIFY: {


			processResult = ManageButton( hWindow, message, wParam, lParam );



		}; break;

		case WM_COMMAND: {

			if ( HIWORD( wParam ) == BN_CLICKED ) {

				if ( IsWindows7SP1OrGreater() ) MessageBox( nullptr, MessageText, MessageCaption, MB_OK );

			};

			processResult = FALSE;

		}; break;

		case WM_PAINT: {


			CONST_OR_CONSTEXPR  SIZE_T rectSize { sizeof( RECT ) };
			CONST_OR_CONSTEXPR  SIZE_T paintstructSize { sizeof( PAINTSTRUCT ) };
			HANDLE const processHeap { GetProcessHeap() };

			LPPAINTSTRUCT ps { reinterpret_cast< LPPAINTSTRUCT >( HeapAlloc( processHeap, HEAP_ZERO_MEMORY, paintstructSize ) ) };
			LPRECT        rect { reinterpret_cast< LPRECT >( HeapAlloc( processHeap, HEAP_ZERO_MEMORY, rectSize ) ) };

			HDC         hdc { BeginPaint( hWindow, ps ) };

			GetClientRect( hWindow, rect );


			DrawText( hdc, reinterpret_cast< LPCWSTR >( defaultWindowText ), -1i32, rect,
				DT_SINGLELINE | DT_CENTER | DT_VCENTER );

			EndPaint( hWindow, ps );

			SecureZeroMemory( reinterpret_cast< PVOID >( ps ), paintstructSize );
			HeapFree( processHeap, {}, reinterpret_cast< LPVOID >( ps ) );
			ps = nullptr;

			SecureZeroMemory( reinterpret_cast< PVOID >( rect ), rectSize );
			HeapFree( processHeap, {}, reinterpret_cast< LPVOID >( rect ) );
			rect = nullptr;

		}; break;


		case WM_CLOSE: DestroyWindow( hWindow ); break;

		case WM_DESTROY: {

			PostQuitMessage( 0i32 );

		}; break;
	};

	processResult = DefWindowProc( hWindow, message, wParam, lParam );

	return processResult;
};


BOOL CALLBACK ManagedChildWindows( HWND handle, LPARAM lParam ) {

	BOOL result {};
	LPRECT clientRect { reinterpret_cast< LPRECT >( lParam ) };
	UINT dpiForWindow { GetDpiForWindow( handle ) };
	int32_t dpiX { MulDiv( ( clientRect->right >> 1i32 ), dpiForWindow, Standard_96DPI ) };
	int32_t dpiY { MulDiv( ( clientRect->bottom >> 1i32 ), dpiForWindow, Standard_96DPI ) };
	int32_t dpiWidth { MulDiv( 200, dpiForWindow, Standard_96DPI ) };
	int32_t dpiHeight { MulDiv( 100, dpiForWindow, Standard_96DPI ) };

	SetWindowPos( handle, nullptr, dpiX, dpiY, dpiWidth, dpiHeight, SWP_NOZORDER | SWP_NOACTIVATE );
	/*MoveWindow( handle, ( clientRect->right >> 1i32 ), ( clientRect->bottom >> 1i32 ), 200, 100, TRUE );*/

	result = ShowWindow( handle, SW_SHOW );

	return result;
};

int WINAPI WinMain( _In_ HINSTANCE hThisInstance, _In_ HINSTANCE hPrevInstance,
	_In_opt_ LPSTR szCmdLine, _In_ int iCmdShow ) {

	CONST_OR_CONSTEXPR char16_t* const applicationName { u"HelloWindowClass" };
	CONST_OR_CONSTEXPR char16_t* const windowCaption { u"The Hello Program" };
	CONST_OR_CONSTEXPR SIZE_T wndclassSizeInBytes { sizeof( WNDCLASSEX ) };
	CONST_OR_CONSTEXPR SIZE_T msgSizeInBytes { sizeof( MSG ) };

	int32_t messageResult {};

	HANDLE const defaultProcessHeap { GetProcessHeap() };
	HWND        hWindow {};
	LPMSG          message { reinterpret_cast< LPMSG >( HeapAlloc( defaultProcessHeap, HEAP_ZERO_MEMORY, msgSizeInBytes ) ) };
	LPWNDCLASSEX     windowClass { reinterpret_cast< LPWNDCLASSEX >( HeapAlloc( defaultProcessHeap, HEAP_ZERO_MEMORY, wndclassSizeInBytes ) ) };

	#pragma region Task 00 - Create main window.

	windowClass->cbSize = wndclassSizeInBytes;
	windowClass->style = ( CS_HREDRAW | CS_VREDRAW );
	windowClass->lpfnWndProc = &WndProc;
	/*windowClass->cbClsExtra = 0;
	windowClass->cbWndExtra = 0;*/
	windowClass->hInstance = hThisInstance; /* Instance of process. */
	windowClass->hIcon = reinterpret_cast< HICON >( LoadImage( nullptr, IDI_APPLICATION, IMAGE_ICON, {}, {}, LR_DEFAULTSIZE | LR_LOADMAP3DCOLORS | LR_LOADTRANSPARENT ) );
	windowClass->hCursor = reinterpret_cast< HCURSOR >( LoadImage( nullptr, IDC_ARROW, IMAGE_CURSOR, {}, {}, LR_DEFAULTSIZE | LR_LOADMAP3DCOLORS | LR_LOADTRANSPARENT ) );
	windowClass->hbrBackground = reinterpret_cast< HBRUSH >( GetStockObject( WHITE_BRUSH ) );
	/*windowClass->lpszMenuName = nullptr;*/
	windowClass->lpszClassName = reinterpret_cast< LPCWSTR >( applicationName );

	if ( !RegisterClassEx( reinterpret_cast< WNDCLASSEX const * >( windowClass ) ) ) {
		MessageBox( nullptr, TEXT( "This program requires Microsoft Windows NT!" ),
			reinterpret_cast< LPCWSTR >( applicationName ), MB_ICONERROR );
	} else {


		hWindow = CreateWindowEx( {}, reinterpret_cast< LPCTSTR >( applicationName ),
			reinterpret_cast< LPCTSTR >( windowCaption ),
			WS_OVERLAPPEDWINDOW | WS_HSCROLL | WS_VSCROLL,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			nullptr,
			nullptr,
			hThisInstance,
			nullptr );

		#pragma endregion

		#pragma region Task 01 - Create child window.

		CreateWindowEx( {}, reinterpret_cast< LPCWSTR >( L"Button" ),
			reinterpret_cast< LPCWSTR >( windowCaption ),
			WS_TABSTOP | WS_CHILDWINDOW | BS_PUSHBUTTON,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_DEFAULT,
			CW_DEFAULT,
			hWindow,
			nullptr,
			hThisInstance,
			nullptr );

		#pragma endregion

		ShowWindow( hWindow, iCmdShow );
		/*
		AnimateWindow( hWindow, 200i32, AW_BLEND | AW_ACTIVATE | AW_SLIDE );
		AnimateWindow( hWindow, 200i32, AW_HOR_POSITIVE );
		AnimateWindow( hWindow, 200i32, AW_HOR_NEGATIVE );
		AnimateWindow( hWindow, 200i32, AW_SLIDE );
		AnimateWindow( hWindow, 200i32, AW_VER_POSITIVE );
		AnimateWindow( hWindow, 200i32, AW_VER_NEGATIVE );
		*/
		UpdateWindow( hWindow );


		while ( messageResult = GetMessage( reinterpret_cast< LPMSG >( message ), nullptr, 0ui32, 0ui32 ) ) {
			TranslateMessage( reinterpret_cast< MSG* >( message ) );
			DispatchMessage( reinterpret_cast< MSG* >( message ) );
		};

	};

	DestroyIcon( windowClass->hIcon );
	DestroyCursor( windowClass->hCursor );

	windowClass = reinterpret_cast< LPWNDCLASSEX >( SecureZeroMemory( reinterpret_cast< LPVOID >( windowClass ), wndclassSizeInBytes ) );

	HeapFree( defaultProcessHeap, {}, reinterpret_cast< LPVOID >( message ) );
	HeapFree( defaultProcessHeap, {}, reinterpret_cast< LPVOID >( windowClass ) );

	message = nullptr;
	windowClass = nullptr;
	const_cast< HANDLE >( defaultProcessHeap ) = nullptr;

	return messageResult;

};



